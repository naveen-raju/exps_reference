#!/bin/bash -x

cwd=`pwd`
cd ~
mkdir -p ~/vim-setup
cd ~/vim-setup

unset http_proxy

mkdir -p ~/.vim
touch ~/.vimrc
mkdir -p ~/.vim/plugin
mkdir -p ~/.vim/colors

tar -xf plugin.tar -C ~/.vim/
tar -xf colors.tar -C ~/.vim/

cat vimrc > ~/.vimrc

cd $cwd
